(function (global, factory) {
	typeof exports === 'object' && typeof module !== 'undefined' ? factory(exports, require('@angular/core'), require('@angular/common'), require('@my-lib/core')) :
	typeof define === 'function' && define.amd ? define(['exports', '@angular/core', '@angular/common', '@my-lib/core'], factory) :
	(factory((global['my-lib'] = global['my-lib'] || {}, global['my-lib'].common = {}),global.ng.core,global.ng.common,global.core));
}(this, (function (exports,core,common,core$1) { 'use strict';

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
var MyCommonModule = (function () {
    function MyCommonModule() {
    }
    return MyCommonModule;
}());
MyCommonModule.decorators = [
    { type: core.NgModule, args: [{
                imports: [common.CommonModule, core$1.MyCoreModule]
            },] },
];
/** @nocollapse */
MyCommonModule.ctorParameters = function () { return []; };

exports.MyCommonModule = MyCommonModule;

Object.defineProperty(exports, '__esModule', { value: true });

})));
//# sourceMappingURL=common.umd.js.map
