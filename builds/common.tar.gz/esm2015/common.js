import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MyCoreModule } from '@my-lib/core';

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
class MyCommonModule {
}
MyCommonModule.decorators = [
    { type: NgModule, args: [{
                imports: [CommonModule, MyCoreModule]
            },] },
];
/** @nocollapse */
MyCommonModule.ctorParameters = () => [];

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
/**
 * Generated bundle index. Do not edit.
 */

export { MyCommonModule };
//# sourceMappingURL=common.js.map
