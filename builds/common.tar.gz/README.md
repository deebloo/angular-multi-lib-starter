# @my-lib/common


```TS
// app.module.ts

import { MyCommonModule } from '@my-lib/common'

@NgModule({
  imports: [MyCommonModule]
})
export class AppModule { }
```

#### Components

| Component                       |
| ------------------------------- |

#### Services

| Service                    |
| -------------------------- |
