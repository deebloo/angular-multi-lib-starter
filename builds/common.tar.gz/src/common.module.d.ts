export declare class MyCommonModule {
}
