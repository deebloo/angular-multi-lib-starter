(function (global, factory) {
	typeof exports === 'object' && typeof module !== 'undefined' ? factory(exports, require('@angular/core')) :
	typeof define === 'function' && define.amd ? define(['exports', '@angular/core'], factory) :
	(factory((global['my-lib'] = global['my-lib'] || {}, global['my-lib'].core = {}),global.ng.core));
}(this, (function (exports,core) { 'use strict';

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
var MyCoreModule = (function () {
    function MyCoreModule() {
    }
    return MyCoreModule;
}());
MyCoreModule.decorators = [
    { type: core.NgModule, args: [{
                providers: []
            },] },
];
/** @nocollapse */
MyCoreModule.ctorParameters = function () { return []; };

exports.MyCoreModule = MyCoreModule;

Object.defineProperty(exports, '__esModule', { value: true });

})));
//# sourceMappingURL=core.umd.js.map
