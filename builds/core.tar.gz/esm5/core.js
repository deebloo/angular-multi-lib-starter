import { NgModule } from '@angular/core';
/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
var MyCoreModule = (function () {
    function MyCoreModule() {
    }
    return MyCoreModule;
}());
MyCoreModule.decorators = [
    { type: NgModule, args: [{
                providers: []
            },] },
];
/** @nocollapse */
MyCoreModule.ctorParameters = function () { return []; };
/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
/**
 * Generated bundle index. Do not edit.
 */
export { MyCoreModule };
//# sourceMappingURL=core.js.map
