# @my-lib/core

```TS
// app.module.ts

import { MyCoreModule } from '@my-lib/core'

@NgModule({
  imports: [MyCoreModule]
})
export class AppModule { }
```

#### Components

| Component                       |
| ------------------------------- |

#### Services

| Service                    |
| -------------------------- |
