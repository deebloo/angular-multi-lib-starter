export declare class MyCoreModule {
}
